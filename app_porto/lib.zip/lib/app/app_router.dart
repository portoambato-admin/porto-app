// lib/app/app_router.dart
import 'package:flutter/material.dart';

import '../features/admin/sections/roles_screen.dart' show RolesScreen;


// Rutas (constantes)
import '../core/constants/route_names.dart';

// Home (NO diferido)
import '../features/public/presentation/screen/home_screen.dart';

// PÚBLICAS diferidas (lazy) — ¡ojo con los alias, evita 'new'!
import '../features/public/presentation/screen/store_screen.dart' deferred as store;
import '../features/public/presentation/screen/events_screen.dart' deferred as events;
import '../features/public/presentation/screen/categories_screen.dart' deferred as categories;
import '../features/public/presentation/screen/benefits_screen.dart' deferred as benefits;
import '../features/public/presentation/screen/about_screen.dart' deferred as about;

// Auth
import '../features/auth/presentation/screens/auth_screen.dart';

// Perfil / Panel (NO diferido)
import '../features/profile/presentation/screens/profile_screen.dart';
import '../features/admin/presentation/panel/panel_screen.dart';

// ===== Admin: Hubs (NUEVO) =====
import '../features/admin/presentation/hubs/personas_hub_screen.dart';
import '../features/admin/presentation/hubs/academia_hub_screen.dart';
import '../features/admin/presentation/hubs/finanzas_hub_screen.dart';
import '../features/admin/presentation/hubs/sistema_hub_screen.dart';

// ===== Admin: secciones (NO lazy, protegidas) =====
import '../features/admin/sections/usuarios_screen.dart';
import '../features/admin/sections/asistencias_screen.dart';
import '../features/admin/sections/categorias_screen.dart' show AdminCategoriasScreen;
import '../features/admin/sections/config_screen.dart' show AdminConfigScreen;
import '../features/admin/sections/admin_pagos_screen.dart' show AdminPagosScreen;

import '../features/admin/presentation/profesores/profesores_screen.dart';
import '../features/admin/sections/estudiantes_screen.dart' show AdminEstudiantesScreen;
import '../features/admin/sections/estudiante_detail_screen.dart' show EstudianteDetailScreen;

// Subcategorías: listado y detalle
import '../features/admin/sections/subcategorias_screen.dart'
  show SubcategoriaEstudiantesScreen;
import '../features/admin/sections/admin_subcategorias_screen.dart'
  show AdminSubcategoriasScreen;

// Sesión
import '../core/services/session.dart';

class AppRouter {
  static Route<dynamic> onGenerateRoute(RouteSettings s) {
    final name = s.name ?? RouteNames.root;

    switch (name) {
      // ======= Públicas ======================================================
      case RouteNames.root:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      case RouteNames.tienda:
        return _loadDeferred(
          s,
          loader: store.loadLibrary(),
          screenBuilder: () => store.StoreScreen(),
        );

      case RouteNames.eventos:
        return _loadDeferred(
          s,
          loader: events.loadLibrary(),
          screenBuilder: () => events.EventsScreen(),
        );

      case RouteNames.categorias:
        return _loadDeferred(
          s,
          loader: categories.loadLibrary(),
          screenBuilder: () => categories.CategoriesScreen(),
        );

      case RouteNames.beneficios:
        return _loadDeferred(
          s,
          loader: benefits.loadLibrary(),
          screenBuilder: () => benefits.BenefitsScreen(),
        );

      case RouteNames.conocenos:
        return _loadDeferred(
          s,
          loader: about.loadLibrary(),
          screenBuilder: () => about.AboutScreen(),
        );

      // ======= Auth ==========================================================
      case RouteNames.auth:
        return MaterialPageRoute(
          settings: s,
          builder: (_) => const AuthScreen(),
        );

      // ======= Protegidas (no lazy) ==========================================
      case RouteNames.perfil:
        return _guardedPlain(s, builder: (_) => const ProfileScreen());

      // Panel centrado (alias /admin)
      case RouteNames.panel:
      case RouteNames.adminRoot:
        return _guardedPlain(s, builder: (_) => const PanelScreen());

      // ======= Hubs base (NUEVOS) ============================================
      case RouteNames.adminPersonas:
        return _guardedPlain(s, builder: (_) => const PersonasHubScreen());

      case RouteNames.adminAcademia:
        return _guardedPlain(s, builder: (_) => const AcademiaHubScreen());

      case RouteNames.adminFinanzas:
        return _guardedPlain(s, builder: (_) => const FinanzasHubScreen());

      case RouteNames.adminSistema:
        return _guardedPlain(s, builder: (_) => const SistemaHubScreen());

      // ======= Subrutas anidadas (NUEVAS) ====================================
      // Personas
      case RouteNames.adminPersonasUsuarios:
        return _guardedPlain(
          s,
          builder: (_) => const PersonasHubScreen(child: UsuariosScreen()),
        );

      case RouteNames.adminPersonasProfesores:
        return _guardedPlain(
          s,
          builder: (_) => PersonasHubScreen(
            child: ProfesoresScreen(embedded: true),
          ),
        );

      // Academia
      case RouteNames.adminAcademiaCategorias:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminCategoriasScreen()),
        );

        

      case RouteNames.adminAcademiaSubcategorias:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminSubcategoriasScreen()),
        );

      case RouteNames.adminAcademiaEstudiantes:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminEstudiantesScreen()),
        );

      case RouteNames.adminAcademiaAsistencias:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminAsistenciasScreen()),
        );

      case RouteNames.adminAcademiaEvaluaciones:
        // ⛑️ Temporal: placeholder hasta alinear el nombre real del widget
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: _EvaluacionesPlaceholder()),
        );

      // Finanzas
      case RouteNames.adminFinanzasPagos:
        return _guardedPlain(
          s,
          builder: (_) => const FinanzasHubScreen(child: AdminPagosScreen()),
        );

      // Sistema
      case RouteNames.adminSistemaConfig:
        return _guardedPlain(
          s,
          builder: (_) => const SistemaHubScreen(child: AdminConfigScreen()),
        );

      // ======= Compatibilidad: rutas antiguas ================================
      case RouteNames.adminUsuarios:
        return _guardedPlain(
          s,
          builder: (_) => const PersonasHubScreen(child: UsuariosScreen()),
        );

      case RouteNames.adminProfesores:
        return _guardedPlain(
          s,
          builder: (_) => PersonasHubScreen(
            child: ProfesoresScreen(embedded: true),
          ),
        );

      case RouteNames.adminCategorias:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminCategoriasScreen()),
        );

      case RouteNames.adminSubcategorias:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminSubcategoriasScreen()),
        );

      case RouteNames.adminAsistencias:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminAsistenciasScreen()),
        );

      case RouteNames.adminEvaluaciones:
        // ⛑️ Temporal: placeholder hasta alinear el nombre real del widget
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: _EvaluacionesPlaceholder()),
        );

      case RouteNames.adminPagos:
        return _guardedPlain(
          s,
          builder: (_) => const FinanzasHubScreen(child: AdminPagosScreen()),
        );

      case RouteNames.adminConfig:
        return _guardedPlain(
          s,
          builder: (_) => const SistemaHubScreen(child: AdminConfigScreen()),
        );
        case RouteNames.adminPersonasRoles:
  return _guardedPlain(
    s,
    builder: (_) => PersonasHubScreen(
      child: RolesScreen(embedded: true),
    ),
  );

      case RouteNames.adminEstudiantes:
        return _guardedPlain(
          s,
          builder: (_) => const AcademiaHubScreen(child: AdminEstudiantesScreen()),
        );

      case RouteNames.adminEstudianteDetalle:
        return _guardedPlain(s, builder: (_) {
          final args = s.arguments;
          int? id;
          if (args is Map && args['id'] != null) {
            final v = args['id'];
            if (v is int) id = v;
            else if (v is num) id = v.toInt();
            else if (v is String) id = int.tryParse(v);
          }
          if (id == null) {
            return const _ArgsErrorPage('Falta argumento: id (int)');
          }
          return AcademiaHubScreen(child: EstudianteDetailScreen(id: id));
        });

      // Subcategoría → Estudiantes (detalle)
      case RouteNames.adminSubcatEstudiantes:
        return _guardedPlain(s, builder: (_) {
          final args = s.arguments is Map ? Map<String, dynamic>.from(s.arguments as Map) : <String, dynamic>{};
          final idSubcat = _arg<int>(args, 'idSubcategoria');
          final nombre   = _arg<String>(args, 'nombreSubcategoria');
          final idCat    = _arg<int>(args, 'idCategoria'); // opcional
          if (idSubcat == null || nombre == null) {
            return const _ArgsErrorPage('Faltan argumentos: idSubcategoria (int) y nombreSubcategoria (String)');
          }
          return AcademiaHubScreen(
            child: SubcategoriaEstudiantesScreen(
              idSubcategoria: idSubcat,
              nombreSubcategoria: nombre,
              idCategoria: idCat,
            ),
          );
        });

      // ======= 404 ===========================================================
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(child: Text('404 — Ruta no encontrada')),
          ),
        );
    }
  }

  // ===== Helpers =====
  static Route<dynamic> _loadDeferred(
    RouteSettings s, {
    required Future<void> loader,
    required Widget Function() screenBuilder,
  }) {
    return MaterialPageRoute(
      settings: s,
      builder: (_) => FutureBuilder<void>(
        future: loader,
        builder: (_, snap) {
          if (snap.connectionState == ConnectionState.done) {
            return screenBuilder();
          }
          return const _LoadingPage();
        },
      ),
    );
  }

  static Route<dynamic> _guardedPlain(
    RouteSettings s, {
    required WidgetBuilder builder,
  }) {
    final String redirectTo = s.name ?? RouteNames.root;

    return MaterialPageRoute(
      settings: s,
      builder: (ctx) => FutureBuilder<String?>(
        future: Session.getToken(),
        builder: (ctx, tokenSnap) {
          if (tokenSnap.connectionState != ConnectionState.done) {
            return const _LoadingPage();
          }
          final token = tokenSnap.data;

          if (RouteNames.guarded.contains(redirectTo) && token == null) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              Navigator.of(ctx).pushNamedAndRemoveUntil(
                RouteNames.auth,
                (r) => false,
                arguments: {'redirectTo': redirectTo},
              );
            });
            return const _LoadingPage();
          }

          return builder(ctx);
        },
      ),
    );
  }

  static T? _arg<T>(Map<String, dynamic> m, String key) {
    final v = m[key];
    if (v == null) return null;
    if (T == int && v is num) return v.toInt() as T;
    if (v is T) return v;
    if (T == int && v is String) return int.tryParse(v) as T?;
    if (T == String) return v.toString() as T;
    return null;
  }
}

class _LoadingPage extends StatelessWidget {
  const _LoadingPage();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}

class _ArgsErrorPage extends StatelessWidget {
  final String message;
  const _ArgsErrorPage(this.message);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Error de argumentos')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(message, textAlign: TextAlign.center),
        ),
      ),
    );
  }
}

// ===== Placeholder temporal para Evaluaciones =====
class _EvaluacionesPlaceholder extends StatelessWidget {
  const _EvaluacionesPlaceholder();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Evaluaciones — pendiente de enlazar widget real',
        style: TextStyle(fontSize: 16),
      ),
    );
  }
}
