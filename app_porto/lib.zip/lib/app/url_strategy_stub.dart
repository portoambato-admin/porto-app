void setAppUrlStrategy() {}
