import 'package:flutter/material.dart';

// ✅ Usa alias para evitar nombres ambiguos
import './admin_subcategorias_screen.dart' as admin hide SubcategoriaEstudiantesScreen;
import './subcategorias_screen.dart' as subcats show SubcategoriaEstudiantesScreen;

class SubcategoriasHubScreen extends StatefulWidget {
  const SubcategoriasHubScreen({super.key});

  @override
  State<SubcategoriasHubScreen> createState() => _SubcategoriasHubScreenState();
}

class _SubcategoriasHubScreenState extends State<SubcategoriasHubScreen>
    with SingleTickerProviderStateMixin {
  Map<String, dynamic>? _selected; // subcategoría elegida
  bool _showDetailOnNarrow = false;

  late final AnimationController _animController;
  late final Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _openDetail(Map<String, dynamic> row) {
    setState(() {
      _selected = row;
      _showDetailOnNarrow = true;
    });
    _animController.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    // Helpers para leer datos de la fila seleccionada de forma segura
    int? _idOf(Map<String, dynamic> r) {
      final v = r['id'] ?? r['id_subcategoria'];
      if (v is num) return v.toInt();
      if (v is String) return int.tryParse(v);
      return null;
    }

    String _nameOf(Map<String, dynamic> r) {
      return (r['nombre'] ?? r['nombre_subcategoria'] ?? '').toString();
    }

    int? _catIdOf(Map<String, dynamic> r) {
      final v = r['idCategoria'] ?? r['id_categoria'];
      if (v is num) return v.toInt();
      if (v is String) return int.tryParse(v);
      return null;
    }

    final Widget detail = (_selected == null)
        ? const _EmptyDetail()
        : subcats.SubcategoriaEstudiantesScreen(
            idSubcategoria: _idOf(_selected!) ?? 0,
            nombreSubcategoria: _nameOf(_selected!),
            idCategoria: _catIdOf(_selected!),
          );

    return Scaffold(
      backgroundColor: cs.surface,
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 2,
        backgroundColor: cs.surface,
        surfaceTintColor: cs.surfaceTint,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: cs.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.category_rounded,
                color: cs.onPrimaryContainer,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            const Text('Subcategorías'),
          ],
        ),
        leading: _showDetailOnNarrow
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => setState(() => _showDetailOnNarrow = false),
              )
            : null,
      ),
      body: LayoutBuilder(
        builder: (ctx, c) {
          final wide = c.maxWidth >= 1100;

          final listPane = _buildListPane(wide, cs);
          final detailPane = _buildDetailPane(wide, cs, detail);

          if (wide) {
            return Row(
              children: [
                Expanded(flex: 5, child: listPane),
                Container(
                  width: 1,
                  color: cs.outlineVariant.withOpacity(0.5),
                ),
                Expanded(flex: 7, child: detailPane),
              ],
            );
          }

          // Móvil/tablet: animación entre lista/detalle
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            switchInCurve: Curves.easeInOut,
            switchOutCurve: Curves.easeInOut,
            transitionBuilder: (child, animation) {
              return FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0.1, 0),
                    end: Offset.zero,
                  ).animate(animation),
                  child: child,
                ),
              );
            },
            child: _showDetailOnNarrow ? detailPane : listPane,
          );
        },
      ),
    );
  }

  Widget _buildListPane(bool wide, ColorScheme cs) {
    return Container(
      decoration: wide
          ? BoxDecoration(
              color: cs.surface,
              border: Border(
                right: BorderSide(
                  color: cs.outlineVariant.withOpacity(0.3),
                ),
              ),
            )
          : null,
      child: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (wide) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Text(
                  'Lista de subcategorías',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: cs.onSurface,
                      ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                child: Text(
                  'Selecciona una subcategoría para gestionar sus estudiantes',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: cs.onSurfaceVariant,
                      ),
                ),
              ),
            ],
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                // ✅ Usa el alias `admin.` para instanciar el widget
                child: admin.AdminSubcategoriasScreen(
                  embedded: true,
                  onOpenEstudiantes: _openDetail,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailPane(bool wide, ColorScheme cs, Widget detail) {
    return Container(
      decoration: wide
          ? BoxDecoration(
              color: cs.surfaceContainerLow,
            )
          : null,
      child: SafeArea(
        bottom: false,
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: detail,
        ),
      ),
    );
  }
}

class _EmptyDetail extends StatelessWidget {
  const _EmptyDetail();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: cs.primaryContainer.withOpacity(0.3),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.touch_app_rounded,
                size: 64,
                color: cs.primary.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Selecciona una subcategoría',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                color: cs.onSurface,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'Elige una subcategoría de la lista para ver y gestionar sus estudiantes inscritos',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: cs.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
