import 'package:flutter/material.dart';
import 'package:app_porto/app/app_scope.dart';
import './subcategorias_screen.dart' show SubcategoriaEstudiantesScreen;

// ===== Enum a nivel superior =====
enum SortSub { nombreAZ, nombreZA }

class StudentsBySubcategoriaScreen extends StatefulWidget {
  const StudentsBySubcategoriaScreen({super.key});
  @override
  State<StudentsBySubcategoriaScreen> createState() => _StudentsBySubcategoriaScreenState();
}

class _StudentsBySubcategoriaScreenState extends State<StudentsBySubcategoriaScreen> {
  late final _subs = AppScope.of(context).subcategorias;
  late final _est  = AppScope.of(context).estudiantes;

  final _qCtrl = TextEditingController();
  List<Map<String, dynamic>> _subList = [];
  final Map<int, List<Map<String, dynamic>>> _cache = {};
  bool _loading = true;
  String? _error;

  // Ordenamiento local
  SortSub _sort = SortSub.nombreAZ;

  @override
  void initState() {
    super.initState();
    _loadSubs();
  }

  @override
  void dispose() {
    _qCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSubs() async {
    setState(() { _loading = true; _error = null; });
    try {
      final all = await _subs.todas(); // método existente
      final actives = all.where((e) => (e['activo'] == true)).toList();
      setState(() => _subList = actives);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<List<Map<String, dynamic>>> _fetchEstudiantes(int idSub) async {
    if (_cache.containsKey(idSub)) return _cache[idSub]!;
    final list = await _est.porSubcategoria(idSub);
    _cache[idSub] = list;
    return list;
  }

  List<Map<String, dynamic>> get _filtered {
    final q = _qCtrl.text.trim().toLowerCase();
    final base = q.isEmpty
        ? _subList
        : _subList.where((s) {
            final nombre = (s['nombre'] ?? s['nombre_subcategoria'] ?? '').toString().toLowerCase();
            return nombre.contains(q);
          }).toList();

    base.sort((a, b) {
      final an = (a['nombre'] ?? a['nombre_subcategoria'] ?? '').toString().toLowerCase();
      final bn = (b['nombre'] ?? b['nombre_subcategoria'] ?? '').toString().toLowerCase();
      return _sort == SortSub.nombreAZ ? an.compareTo(bn) : bn.compareTo(an);
    });
    return base;
  }

  String _letterOf(Map s) {
    final n = (s['nombre'] ?? s['nombre_subcategoria'] ?? '').toString().trim();
    return n.isEmpty ? '#' : n[0].toUpperCase();
  }

  Widget _skeleton() => ListView.builder(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
        itemCount: 6,
        itemBuilder: (_, __) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          height: 76,
          decoration: BoxDecoration(
            color: Colors.black12.withOpacity(.06),
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);

    final searchBar = Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _qCtrl,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Buscar subcategoría…',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                suffixIcon: _qCtrl.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () { _qCtrl.clear(); setState(() {}); },
                      ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          DropdownButton<SortSub>(
            value: _sort,
            onChanged: (v){ if (v!=null) setState(()=>_sort=v); },
            items: [
              DropdownMenuItem(value: SortSub.nombreAZ, child: Text('A → Z')),
              DropdownMenuItem(value: SortSub.nombreZA, child: Text('Z → A')),
            ],
          ),
          IconButton(
            tooltip: 'Recargar',
            onPressed: _loading ? null : () async { _cache.clear(); await _loadSubs(); },
            icon: _loading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
          ),
        ],
      ),
    );

    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Estudiantes por subcategoría')),
        body: Column(
          children: [
            searchBar,
            const Divider(height: 1),
            Expanded(child: _skeleton()),
          ],
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Estudiantes por subcategoría')),
        body: Column(
          children: [
            searchBar,
            const Divider(height: 1),
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.error_outline, size: 48),
                          const SizedBox(height: 8),
                          Text('Ocurrió un error', style: t.textTheme.titleMedium),
                          const SizedBox(height: 6),
                          Text(_error!, textAlign: TextAlign.center),
                          const SizedBox(height: 12),
                          FilledButton.icon(
                            onPressed: _loadSubs,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Reintentar'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    // Agrupar por inicial
    final data = _filtered;
    String? currentLetter;
    final widgets = <Widget>[];
    for (final s in data) {
      final id = (s['id'] ?? s['id_subcategoria']) as int;
      final nombre = (s['nombre'] ?? s['nombre_subcategoria'] ?? '—').toString();
      final l = _letterOf(s);
      if (l != currentLetter) {
        currentLetter = l;
        widgets.add(Padding(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 6),
          child: Text(l, style: const TextStyle(fontWeight: FontWeight.w700)),
        ));
      }

      widgets.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
          child: Card(
            elevation: 0,
            clipBehavior: Clip.antiAlias,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Theme(
              data: t.copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
                childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                leading: CircleAvatar(child: Text(nombre.characters.take(2).toString().toUpperCase())),
                title: Text(nombre, style: t.textTheme.titleMedium),
                subtitle: const Text('Estudiantes asignados'),
                trailing: Wrap(
                  spacing: 8,
                  children: [
                    OutlinedButton.icon(
                      icon: const Icon(Icons.open_in_new),
                      label: const Text('Abrir detalle'),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => SubcategoriaEstudiantesScreen(
                            idSubcategoria: id,
                            nombreSubcategoria: nombre,
                            idCategoria: s['idCategoria'] as int?,
                          ),
                        ));
                      },
                    ),
                  ],
                ),
                children: [
                  FutureBuilder<List<Map<String, dynamic>>>(
                    future: _fetchEstudiantes(id),
                    builder: (_, snap) {
                      if (snap.connectionState != ConnectionState.done) {
                        return const Padding(
                          padding: EdgeInsets.all(16),
                          child: LinearProgressIndicator(),
                        );
                      }
                      final items = snap.data ?? [];
                      if (items.isEmpty) {
                        return const Padding(
                          padding: EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Icon(Icons.group_outlined),
                              SizedBox(width: 8),
                              Text('Sin estudiantes.'),
                            ],
                          ),
                        );
                      }
                      return ListView.separated(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, j) {
                          final e = items[j];
                          final nombres = (e['nombres'] ?? '').toString();
                          final apellidos = (e['apellidos'] ?? '').toString();
                          final idEst = e['id'] ?? e['id_estudiante'] ?? '—';
                          return ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                            leading: const Icon(Icons.person),
                            title: Text('$nombres $apellidos'),
                            subtitle: Text('ID: $idEst'),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Estudiantes por subcategoría'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Chip(
              avatar: const Icon(Icons.category, size: 18),
              label: Text('${_filtered.length} subcategorías'),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          searchBar,
          const Divider(height: 1),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async { _cache.clear(); await _loadSubs(); },
              child: _filtered.isEmpty
                  ? const Center(child: Text('No hay subcategorías que coincidan.'))
                  : ListView(children: widgets),
            ),
          ),
        ],
      ),
    );
  }
}
