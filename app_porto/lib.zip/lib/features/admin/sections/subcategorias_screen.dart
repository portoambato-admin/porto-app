
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:characters/characters.dart'; // para usar .characters
import '../../../app/app_scope.dart';

// ===== Helpers UI (sin cambios) =====
String _iniciales(String nombres, String apellidos) {
  final n = nombres.trim().isEmpty ? '' : nombres.trim().split(' ').first;
  final a = apellidos.trim().isEmpty ? '' : apellidos.trim().split(' ').first;
  final i1 = n.isEmpty ? '' : n.characters.first;
  final i2 = a.isEmpty ? '' : a.characters.first;
  final r = (i1 + i2).toUpperCase();
  return r.isEmpty ? '👤' : r;
}

int? _toIntOrNull(dynamic v) {
  if (v == null) return null;
  if (v is int) return v;
  if (v is num) return v.toInt();
  return int.tryParse('$v');
}

Color _avatarColor(String seed){
  final h = seed.hashCode & 0xFFFFFF;
  // Se usa el 0xFF000000 para forzar el canal Alpha a 1 (opaco) y aplicar el color.
  return Color(0xFF000000 | h).withOpacity(1); 
}

// ===== Enums (sin cambios) =====
enum ViewMode { cards, table }
enum SortBy { apellidoAZ, apellidoZA, nombreAZ, reciente }

class SubcategoriaEstudiantesScreen extends StatefulWidget {
  final int idSubcategoria;
  final String nombreSubcategoria;
  final int? idCategoria; // para matrícula

  const SubcategoriaEstudiantesScreen({
    super.key,
    required this.idSubcategoria,
    required this.nombreSubcategoria,
    this.idCategoria,
  });

  @override
  State<SubcategoriaEstudiantesScreen> createState() => _SubcategoriaEstudiantesScreenState();
}

class _SubcategoriaEstudiantesScreenState extends State<SubcategoriaEstudiantesScreen> {
  // Repos existentes
  late final _subcatEst = AppScope.of(context).subcatEst;
  late final _est = AppScope.of(context).estudiantes;
  late final _subcatRepo = AppScope.of(context).subcategorias;
  bool _loading = false;
  String? _error;
  
  // MEJORA: _rows es la fuente de verdad. _filteredRows es la data de UI.
  List<Map<String, dynamic>> _rows = [];
  List<Map<String, dynamic>> _filteredRows = [];

  // UI/UX solo front
  final _qCtrl = TextEditingController();
  bool _soloActivos = true;
  ViewMode _view = ViewMode.cards;
  SortBy _sort = SortBy.apellidoAZ;
  final Set<int> _selected = {}; // Set de IDs de estudiantes seleccionados

  // MEJORA: KPIs cacheados para no calcularlos en cada build
  int _countTotal = 0;
  int _countActivos = 0;
  int _countInactivos = 0;

  @override
  void initState() {
    super.initState();
    // Añadimos el listener para el buscador
    _qCtrl.addListener(_recalculateUiData);
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _qCtrl.removeListener(_recalculateUiData);
    _qCtrl.dispose();
    super.dispose();
  }

  // Lógica de carga sin cambios
  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final asign = await _subcatEst.porSubcategoria(widget.idSubcategoria);

      final list = <Map<String, dynamic>>[];
      // MEJORA (N+1): Mapa para guardar temporalmente data
      // y los IDs que necesitamos fetchear
      final Map<int, Map<String, dynamic>> pendingInfoMaps = {};

      for (final a in asign) {
        final idEst = _toIntOrNull(a['idEstudiante'] ?? a['id'] ?? a['id_estudiante']);
        if (idEst == null) continue;

        String? nombres = a['nombres']?.toString();
        String? apellidos = a['apellidos']?.toString();

        if ((nombres == null || apellidos == null) && a['estudiante'] != null) {
          final s = a['estudiante'].toString().trim();
          final parts = s.split(RegExp(r'\s+'));
          if (parts.length >= 2) {
            nombres = parts.sublist(0, parts.length - 1).join(' ');
            apellidos = parts.last;
          } else {
            nombres = s; apellidos = '';
          }
        }

        final data = {
          'id': idEst,
          'nombres': nombres, // Puede ser null temporalmente
          'apellidos': apellidos, // Puede ser null temporalmente
          'activo': (a['activo'] is bool) ? a['activo'] : true,
        };
        
        list.add(data);

        // Si faltan datos, lo marcamos para el fetch en bloque
        if (nombres == null || apellidos == null) {
          pendingInfoMaps[idEst] = data;
        }
      }

      // MEJORA (N+1): Hacemos 1 solo batch de llamadas (Future.wait)
      if (pendingInfoMaps.isNotEmpty) {
        try {
          final futures = pendingInfoMaps.keys.map(
            (id) => _est.byId(id).catchError((_) => null) // .catchError para que no falle todo
          ).toList();
          
          final results = await Future.wait(futures);

          // Creamos un mapa de ID -> Info para mergear fácil
          final infoMap = <int, Map<String, dynamic>?>{};
          int i = 0;
          for (final id in pendingInfoMaps.keys) {
            infoMap[id] = results[i];
            i++;
          }

          // Mergeamos la info faltante
          for (final dataMap in pendingInfoMaps.values) {
            final id = dataMap['id'] as int;
            final info = infoMap[id];
            dataMap['nombres'] = info?['nombres']?.toString() ?? dataMap['nombres'] ?? '—';
            dataMap['apellidos'] = info?['apellidos']?.toString() ?? dataMap['apellidos'] ?? '';
          }
        } catch (_) {
          // El catchError de arriba debería prevenir esto, pero por si acaso
        }
      }
      
      // Llenamos los '—' de los que no se pudieron cargar
      for (final r in list) {
        r['nombres'] = r['nombres'] ?? '—';
        r['apellidos'] = r['apellidos'] ?? '';
      }

      setState(() {
        _rows = list;
        _selected.clear();
      });

    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      // MEJORA: Recalculamos la UI (KPIs y filtros) al final
      if (mounted) {
        setState(() => _loading = false);
        _recalculateUiData();
      }
    }
  }

  List<Map<String, dynamic>> _sortRows(List<Map<String,dynamic>> list) {
    final r = [...list];
    int cmp(String a, String b) => a.toLowerCase().compareTo(b.toLowerCase());
    switch (_sort) {
      case SortBy.apellidoAZ: r.sort((a,b)=>cmp('${a['apellidos']}','${b['apellidos']}')); break;
      case SortBy.apellidoZA: r.sort((a,b)=>cmp('${b['apellidos']}','${a['apellidos']}')); break;
      case SortBy.nombreAZ: r.sort((a,b)=>cmp('${a['nombres']}','${b['nombres']}')); break;
      // Asumiendo que un ID más alto es "más reciente"
      case SortBy.reciente: r.sort((a,b)=>((b['id']??0) as int).compareTo((a['id']??0) as int)); break; 
    }
    return r;
  }

  // MEJORA: Función central para recalcular datos de UI (KPIs y lista filtrada)
  void _recalculateUiData() {
    // 1. Calcular KPIs
    _countTotal = _rows.length;
    _countActivos = _rows.where((e) => e['activo'] == true).length;
    _countInactivos = _countTotal - _countActivos;

    // 2. Calcular Lista Filtrada
    final q = _qCtrl.text.trim().toLowerCase();
    final base = _rows.where((r) {
      if (_soloActivos && r['activo'] == false) return false;
      if (q.isEmpty) return true;
      final n = (r['nombres'] ?? '').toString().toLowerCase();
      final a = (r['apellidos'] ?? '').toString().toLowerCase();
      return n.contains(q) || a.contains(q) || ('$n $a').contains(q);
    }).toList();
    
    _filteredRows = _sortRows(base);

    // 3. Notificar a la UI
    if (mounted) {
      // Usar setState solo si no estamos ya en un setState (como en _load)
      if (TickerMode.of(context)) { 
        setState(() {});
      }
    }
  }

  // NUEVO: Toggle estado para seleccionados (visual, sin tocar el back)
  void _toggleSelectedStatus() {
    if (_selected.isEmpty) return;
    
    int toggledCount = 0;
    setState(() {
      for (var r in _rows) {
        final id = _toIntOrNull(r['id']);
        if (id != null && _selected.contains(id)) {
          r['activo'] = !(r['activo'] == true); 
          toggledCount++;
        }
      }
      _recalculateUiData(); // Recalcula para actualizar lista filtrada y KPIs
    });

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Se cambió el estado de $toggledCount estudiante(s) (Visual).')),
    );
  }

  // ====== KPIs ======
  // MEJORA: Ahora usa las variables de estado cacheadas
  Widget _kpiChips() {
    Chip _c(IconData i, String t, String v) => Chip(
      avatar: Icon(i, size: 18),
      label: Text('$t: $v'),
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
    return Wrap(
      spacing: 8, runSpacing: 8,
      children: [
        _c(Icons.people, 'Total', '$_countTotal'),
        _c(Icons.verified_user, 'Activos', '$_countActivos'),
        _c(Icons.person_off, 'Inactivos', '$_countInactivos'),
      ],
    );
  }

  // ===== Export CSV (copiar al portapapeles) =====
  String _csv(List<Map<String,dynamic>> rows){
    const cols = ['id','nombres','apellidos','activo'];
    String esc(v){ final s='${v??''}'; return '"${s.replaceAll('"','""')}"'; }
    final header = cols.map(esc).join(',');
    final lines = rows.map((r)=>cols.map((c)=>esc(r[c])).join(','));
    return ([header, ...lines]).join('\n');
  }

  Future<void> _exportCsvSelected() async {
    // Si hay seleccionados, exporta la selección, si no, exporta la lista filtrada.
    final toExport = _selected.isEmpty 
        ? _filteredRows 
        : _rows.where((r)=>_selected.contains(r['id'])).toList();
        
    final content = _csv(toExport); 
    await Clipboard.setData(ClipboardData(text: content));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('CSV (${toExport.length} filas) copiado al portapapeles')),
    );
  }

  void _printList() {
    showDialog(context: context, builder: (_)=>AlertDialog(
      title: const Text('Impresión'),
      content: const Text('Vista de impresión en desarrollo (solo UI).'),
      actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('Cerrar'))],
    ));
  }

  // ====== Asignación masiva (sin pedir IDs) ======
  // ====== Asignación masiva (MEJORADO) ======
  Future<void> _asignarMasivoDialog() async {
    if (_selected.isEmpty) return;

    // Tomar los nombres para mostrar en el diálogo
    final selectedNames = _rows
        .where((r) => _selected.contains(r['id']))
        .map((r) => '${r['nombres']} ${r['apellidos']}'.trim())
        .take(5) // Tomar los primeros 5 como muestra
        .toList();

    // Mostrar el diálogo mejorado, que ahora es un widget Stateful
    // Devuelve el ID de destino (int?) o null si se cancela
    final int? destino = await showDialog<int?>(
      context: context,
      builder: (_) {
        return _AsignacionDialog(
          subcatRepo: _subcatRepo, // Pasar el repo
          idSubcategoriaActual: widget.idSubcategoria,
          selectedCount: _selected.length,
          selectedNames: selectedNames,
        );
      },
    );

    // Si el usuario cancela (destino == null)
    if (destino == null) return;

    // Muestra el loader
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    // Lógica de asignación (la misma de antes, ahora usa el 'destino' devuelto)
    try {
      final futures = _selected.map((idEst) => _subcatEst
          .asignar(
            idEstudiante: idEst,
            idSubcategoria: destino, // Usar el destino devuelto
          )
          .then((_) => true) // Marcamos éxito
          .catchError((e) {
            debugPrint('Error asignando $idEst: $e');
            return false; // Marcamos fracaso
          }));

      final results = await Future.wait(futures);

      if (!mounted) return;
      Navigator.pop(context); // cierra loader

      final successCount = results.where((r) => r == true).length;
      final errorCount = results.length - successCount;

      String msg = 'Asignados $successCount estudiante(s).';
      if (errorCount > 0) {
        msg += ' Fallaron $errorCount.';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg)),
      );
      // Limpiamos la selección
      setState(() => _selected.clear());

    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // cierra loader
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error inesperado al asignar: $e')),
      );
    }
  }

  // ====== UI Helpers ======
  String _letterOf(Map r) {
    final base = (r['apellidos'] ?? r['nombres'] ?? '').toString().trim();
    return base.isEmpty ? '#' : base[0].toUpperCase();
  }

  Widget _skeleton() => ListView.builder(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 110),
        itemCount: 6,
        itemBuilder: (_, __) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          height: 72,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(.4), // Usar color de tema
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      );

  // Método simulado
  Future<void> _inscribir() async {
    // ... (Toda la lógica de _inscribir se mantiene igual) ...
    // Navegación simulada a la pantalla de inscripción
    Navigator.pushNamed(context, '/admin/estudiantes/inscripcion', 
      arguments: {'idSubcategoria': widget.idSubcategoria, 'nombreSubcategoria': widget.nombreSubcategoria}
    );
  }

  // MEJORA: Barra de acciones cuando hay selección
  PreferredSizeWidget _selectionBar(BuildContext ctx) => AppBar(
    leading: IconButton(
      icon: const Icon(Icons.close),
      onPressed: () => setState(() => _selected.clear()),
      tooltip: 'Limpiar selección',
    ),
    title: Text('${_selected.length} seleccionado(s)'),
    actions: [
      IconButton(
        tooltip: 'Asignar a subcategoría…',
        icon: const Icon(Icons.assignment_ind_outlined),
        onPressed: _selected.isEmpty ? null : _asignarMasivoDialog,
      ),
      // NUEVO: Botón de alternar estado (Activo/Inactivo)
      IconButton(
        tooltip: 'Activar/Desactivar seleccionados (Visual)',
        icon: const Icon(Icons.toggle_on_outlined),
        onPressed: _selected.isEmpty ? null : _toggleSelectedStatus,
      ),
      IconButton(
        icon: const Icon(Icons.download),
        onPressed: _selected.isEmpty ? null : _exportCsvSelected,
        tooltip: 'Exportar CSV (seleccionados)',
      ),
      IconButton(
        icon: const Icon(Icons.print),
        onPressed: _selected.isEmpty ? null : _printList,
        tooltip: 'Imprimir',
      ),
    ],
  );

  Widget _buildHeader(BuildContext context, ThemeData t) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [t.colorScheme.primaryContainer, t.colorScheme.surface],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
        border: Border(bottom: BorderSide(color: t.colorScheme.outlineVariant)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 20,
                    child: Text(widget.nombreSubcategoria.characters.take(2).toString().toUpperCase()),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      widget.nombreSubcategoria,
                      style: t.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              _kpiChips(), // Usa los KPIs cacheados
              const SizedBox(height: 10),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end, // Alinea al final para el TextField y el Dropdown
                children: [
                  Expanded(
                    child: TextField(
                      controller: _qCtrl,
                      decoration: InputDecoration(
                        hintText: 'Buscar por nombre o apellido…',
                        prefixIcon: const Icon(Icons.search),
                        helperText: 'Selecciona por checkbox para asignación masiva',
                        filled: true,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        suffixIcon: _qCtrl.text.isEmpty
                            ? null
                            : IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () { _qCtrl.clear(); },
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // MEJORA: SegmentedButton con íconos más claros
                  SegmentedButton<ViewMode>(
                    segments: const [
                      ButtonSegment(value: ViewMode.cards, icon: Icon(Icons.view_agenda), label: Text('Tarjetas')),
                      ButtonSegment(value: ViewMode.table, icon: Icon(Icons.table_rows), label: Text('Tabla')),
                    ],
                    selected: {_view},
                    onSelectionChanged: (s)=>setState(()=>_view=s.first),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // MEJORA: Se movió la organización al pie para no saturar la búsqueda
                  DropdownButton<SortBy>(
                    value: _sort,
                    onChanged: (v){ 
                      if (v!=null) {
                        setState(()=>_sort=v);
                        _recalculateUiData(); // Recalcula al cambiar sort
                      }
                    },
                    items: const [
                      DropdownMenuItem(value: SortBy.apellidoAZ, child: Text('Apellido A→Z')),
                      DropdownMenuItem(value: SortBy.apellidoZA, child: Text('Apellido Z→A')),
                      DropdownMenuItem(value: SortBy.nombreAZ,  child: Text('Nombre A→Z')),
                      DropdownMenuItem(value: SortBy.reciente,  child: Text('Más recientes')),
                    ],
                  ),
                  const SizedBox(width: 12),
                  FilterChip(
                    label: const Text('Solo activos'),
                    selected: _soloActivos,
                    onSelected: (v) {
                      setState(() => _soloActivos = v);
                      _recalculateUiData(); // Recalcula al cambiar filtro
                    },
                  ),
                  const SizedBox(width: 6),
                  IconButton(
                    tooltip: 'Recargar',
                    onPressed: _loading ? null : _load,
                    icon: _loading
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.refresh),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardView(BuildContext context, ThemeData t) {
    if (_loading) return _skeleton();
    if (_error != null) {
      // Muestra el error con un botón para reintentar
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Error al cargar datos: ${_error!}', style: t.textTheme.bodyMedium?.copyWith(color: t.colorScheme.error)),
                  const SizedBox(height: 10),
                  TextButton.icon(
                    onPressed: _load,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Reintentar'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    
    final data = _filteredRows; 
    
    if (data.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                _qCtrl.text.isEmpty
                    ? 'Sin estudiantes en esta subcategoría.'
                    : 'No se encontraron resultados para "${_qCtrl.text}".',
              ),
            ),
          ),
        ),
      );
    }

    // Agrupar por inicial
    String? current;
    final widgets = <Widget>[];
    for (final r in data) {
      final l = _letterOf(r);
      if (l != current) {
        current = l;
        widgets.add(Padding(
          padding: const EdgeInsets.fromLTRB(12, 16, 12, 6),
          child: Text(l, style: t.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
        ));
      }

      final id = _toIntOrNull(r['id']) ?? 0;
      final nombres = (r['nombres'] ?? '').toString();
      final apellidos = (r['apellidos'] ?? '').toString();
      final activo = (r['activo'] == true);

      widgets.add(
        Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            // MEJORA: Resaltar selección
            side: _selected.contains(id) 
                ? BorderSide(color: t.colorScheme.primary, width: 2) 
                : BorderSide.none,
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.fromLTRB(12, 6, 6, 6),
            leading: SizedBox(
              width: 72,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Checkbox(
                    value: _selected.contains(id),
                    onChanged: (v){
                      setState(()=> v==true ? _selected.add(id) : _selected.remove(id));
                    },
                  ),
                  const SizedBox(width: 4),
                  CircleAvatar(
                    backgroundColor: _avatarColor('$nombres $apellidos'),
                    child: Text(_iniciales(nombres, apellidos)),
                  ),
                ],
              ),
            ),
            title: Text('$nombres $apellidos', style: t.textTheme.titleMedium),
            // MEJORA: Usar ícono y texto para estado en lugar de Chip
            subtitle: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  activo ? Icons.check_circle : Icons.cancel,
                  color: activo ? t.colorScheme.primary : t.colorScheme.error,
                  size: 16,
                ),
                const SizedBox(width: 4),
                Text(activo ? 'Activo' : 'Inactivo', style: t.textTheme.bodySmall),
              ],
            ),
            trailing: PopupMenuButton<String>(
              tooltip: 'Acciones',
              onSelected: (value) {
                final studentId = id;
                if (value == 'ver') {
                  Navigator.pushNamed(
                    context,
                    '/admin/estudiantes/detalle',
                    arguments: {'id': studentId},
                  );
                } else if (value == 'mover') {
                  setState(() {
                    _selected
                      ..clear()
                      ..add(studentId);
                  });
                  _asignarMasivoDialog();
                } else if (value == 'toggle') {
                  final idx = _rows.indexWhere((e) => _toIntOrNull(e['id']) == studentId);
                  if (idx != -1) {
                    setState(() {
                      _rows[idx]['activo'] = !(_rows[idx]['activo'] == true);
                      _recalculateUiData();
                    });
                  }
                }
              },
              itemBuilder: (ctx) => [
                const PopupMenuItem(
                  value: 'ver',
                  child: ListTile(
                    leading: Icon(Icons.person_search_outlined),
                    title: Text('Ver detalle'),
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
                const PopupMenuItem(
                  value: 'mover',
                  child: ListTile(
                    leading: Icon(Icons.swap_horiz),
                    title: Text('Mover a otra subcategoría…'),
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
                PopupMenuItem(
                  value: 'toggle',
                  child: ListTile(
                    leading: Icon(Icons.toggle_on_outlined),
                    title: Text('Activar/Desactivar (visual)'),
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ],
            ),
            onTap: () => Navigator.pushNamed(
              context,
              '/admin/estudiantes/detalle',
              arguments: {'id': id},
            ),
            onLongPress: () {
              // MEJORA UX: Al hacer long press se activa la selección
              setState(() => _selected.add(id));
            },
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 110),
        children: widgets,
      ),
    );
  }

  Widget _buildTableView(BuildContext context, ThemeData t) {
    if (_loading) return _skeleton();
    if (_error != null) {
      return Center(child: Text(_error!));
    }
    
    final data = _filteredRows;
    
    if (data.isEmpty) {
      return Center(
        child: Text(_qCtrl.text.isEmpty ? 'Sin estudiantes.' : 'No hay coincidencias.'),
      );
    }
    
    // Calcular estado de selección para el encabezado
    final bool allSelected = data.isNotEmpty && data.every((r) => _selected.contains(_toIntOrNull(r['id'])));
    final bool someSelected = data.any((r) => _selected.contains(_toIntOrNull(r['id'])));

    return RefreshIndicator(
      onRefresh: _load,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 110),
        scrollDirection: Axis.horizontal,
        child: DataTable(
          // MEJORA: Permite seleccionar todos los filtrados
          columns: [
            DataColumn(
              label: Checkbox(
                tristate: true,
                value: allSelected ? true : (someSelected ? null : false),
                onChanged: (v) {
                  setState(() {
                    if (v == true || v == null) { // Si se selecciona (true o null por tristate), seleccionar todos
                      for (final r in data) {
                        final id = _toIntOrNull(r['id']);
                        if (id != null) _selected.add(id);
                      }
                    } else { // Si se deselecciona (false), deseleccionar todos
                      for (final r in data) {
                        final id = _toIntOrNull(r['id']);
                        if (id != null) _selected.remove(id);
                      }
                    }
                  });
                },
              ),
            ),
            const DataColumn(label: Text('Estudiante')),
            const DataColumn(label: Text('Estado')),
          ],
          rows: [
            for (final r in data)
              () {
                final rid = _toIntOrNull(r['id']);
                final isSelected = rid != null && _selected.contains(rid);
                return DataRow(
                  selected: isSelected, // Resalta la fila si está seleccionada
                  onSelectChanged: (v) {
                     setState(() {
                       if (rid != null) {
                         v == true ? _selected.add(rid) : _selected.remove(rid);
                       }
                     });
                  },
                  cells: [
                    DataCell(Checkbox(
                      value: isSelected,
                      onChanged: (v){
                        setState(() {
                          if (rid != null) {
                            v == true ? _selected.add(rid) : _selected.remove(rid);
                          }
                        });
                      },
                    )),
                    DataCell(Text('${r['nombres']} ${r['apellidos']}')),
                    DataCell(Text(r['activo']==true ? 'Activo' : 'Inactivo')),
                  ],
                );
              }(),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);

    // MEJORA: Lógica del FAB contextual
    Widget fab;
    if (_selected.isEmpty) {
      fab = FloatingActionButton(
        onPressed: _inscribir,
        tooltip: 'Inscribir estudiante',
        child: const Icon(Icons.person_add),
      );
    } else {
      // FAB Extendido para acciones de selección
      final isSingle = _selected.length == 1;
      final label = isSingle ? 'Ver Detalle' : 'Asignar (${_selected.length})';
      final icon = isSingle ? Icons.person_search_outlined : Icons.assignment_ind_outlined;
      final action = isSingle 
          ? () { // Navegar al detalle del único seleccionado
              final id = _selected.first;
              Navigator.pushNamed(context, '/admin/estudiantes/detalle', arguments: {'id': id});
            } 
          : _asignarMasivoDialog; // Asignación masiva

      fab = FloatingActionButton.extended(
        onPressed: action,
        tooltip: isSingle ? 'Ver detalle del estudiante seleccionado' : 'Asignación masiva de estudiantes',
        label: Text(label),
        icon: Icon(icon),
      );
    }


    return Scaffold(
      // Muestra la barra de selección si hay elementos seleccionados
      appBar: _selected.isEmpty
          ? AppBar(
              title: Text(widget.nombreSubcategoria),
              actions: [
                if (_loading) // Indicador de carga en AppBar
                  const Padding(
                    padding: EdgeInsets.only(right: 12),
                    child: Center(
                      child: SizedBox(
                        width: 20, height: 20, 
                        child: CircularProgressIndicator(strokeWidth: 2)
                      ),
                    ),
                  )
                else // Chip de conteo de filtrados
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Chip(
                      avatar: const Icon(Icons.group, size: 18),
                      label: Text('${_filteredRows.length}'), 
                    ),
                  ),
                IconButton(
                  icon: const Icon(Icons.download),
                  tooltip: 'Exportar CSV (lista filtrada)',
                  onPressed: _exportCsvSelected,
                ),
              ],
            )
          : _selectionBar(context), // Barra de selección activa
      
      floatingActionButton: fab, // FAB Contextual
      
      body: Column(
        children: [
          // Header con filtros y KPIs
          _buildHeader(context, t),
          Expanded(
            // Vistas extraídas
            child: _view == ViewMode.cards 
              ? _buildCardView(context, t) 
              : _buildTableView(context, t),
          ),
        ],
      ),
    );
  }
}// =========== WIDGET INTERNO PARA EL DIÁLOGO DE ASIGNACIÓN ===========

class _AsignacionDialog extends StatefulWidget {
  final dynamic subcatRepo; // Repositorio de subcategorías
  final int idSubcategoriaActual;
  final int selectedCount;
  final List<String> selectedNames; // Muestra de nombres

  const _AsignacionDialog({
    required this.subcatRepo,
    required this.idSubcategoriaActual,
    required this.selectedCount,
    required this.selectedNames,
  });

  @override
  State<_AsignacionDialog> createState() => _AsignacionDialogState();
}

class _AsignacionDialogState extends State<_AsignacionDialog> {
  int? _destino; // El ID de la subcategoría de destino seleccionada
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _opciones = [];

  @override
  void initState() {
    super.initState();
    _loadSubcategorias();
  }

  Future<void> _loadSubcategorias() async {
    setState(() { _loading = true; _error = null; });
    try {
      // Asumimos que el repo tiene un método .all() que devuelve la lista
      final List<Map<String, dynamic>> todas = await widget.subcatRepo.all();
      
      // Filtramos la subcategoría actual (no podemos mover a donde ya estamos)
      _opciones = todas.where((sub) {
        final id = _toIntOrNull(sub['id']);
        return id != null && id != widget.idSubcategoriaActual;
      }).toList();
      
      // Ordenamos alfabéticamente por nombre
      _opciones.sort((a, b) => (a['nombre'] ?? '').toString().toLowerCase()
          .compareTo((b['nombre'] ?? '').toString().toLowerCase()));

    } catch (e) {
      _error = "Error cargando subcategorías: $e";
    } finally {
      if (mounted) {
        setState(() { _loading = false; });
      }
    }
  }

  Widget _buildContent() {
    if (_loading) {
      return const Center(child: Padding(
        padding: EdgeInsets.all(16.0),
        child: CircularProgressIndicator(),
      ));
    }
    if (_error != null) {
      return Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error));
    }
    if (_opciones.isEmpty) {
      return const Text('No hay otras subcategorías disponibles para mover.');
    }

    // El Dropdown real
    return DropdownButtonFormField<int>(
      value: _destino,
      hint: const Text('Seleccionar destino...'),
      isExpanded: true,
      decoration: const InputDecoration(border: OutlineInputBorder()),
      items: _opciones.map((sub) {
        return DropdownMenuItem<int>(
          value: _toIntOrNull(sub['id']),
          child: Text(
            sub['nombre']?.toString() ?? 'ID: ${sub['id']}',
            overflow: TextOverflow.ellipsis,
          ),
        );
      }).toList(),
      onChanged: (value) {
        setState(() {
          _destino = value;
        });
      },
      validator: (value) => value == null ? 'Debe seleccionar un destino' : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return AlertDialog(
      title: const Text('Asignación Masiva'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Mover ${widget.selectedCount} estudiante(s):'),
          const SizedBox(height: 4),
          // Muestra los nombres de ejemplo
          if (widget.selectedNames.isNotEmpty)
            Opacity(
              opacity: 0.7,
              child: Text(
                widget.selectedNames.join(', ') + (widget.selectedCount > widget.selectedNames.length ? ', ...' : ''),
                style: t.textTheme.bodySmall,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          const SizedBox(height: 20),
          const Text('Mover a:'),
          const SizedBox(height: 8),
          // Contenedor para el dropdown
          SizedBox(
            width: 400, // Ancho fijo para el diálogo en web/desktop
            child: _buildContent(),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, null), // Cancelar
          child: const Text('Cancelar'),
        ),
        FilledButton.icon(
          // Deshabilitado si no hay destino o si está cargando
          onPressed: (_destino == null || _loading)
              ? null 
              : () => Navigator.pop(context, _destino), // Confirmar
          icon: const Icon(Icons.check),
          label: const Text('Asignar'),
        ),
      ],
    );
  }
}