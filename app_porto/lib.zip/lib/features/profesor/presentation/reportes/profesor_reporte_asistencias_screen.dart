import 'package:flutter/material.dart';

class ProfesorReporteAsistenciasScreen extends StatelessWidget {
  const ProfesorReporteAsistenciasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(title: Text('Reporte de asistencias')),
      body: Center(child: Text('TODO: conectar endpoint + filtros + exportación')),
    );
  }
}
