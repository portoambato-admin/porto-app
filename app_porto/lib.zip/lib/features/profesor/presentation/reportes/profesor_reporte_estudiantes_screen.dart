import 'package:flutter/material.dart';

class ProfesorReporteEstudiantesScreen extends StatelessWidget {
  const ProfesorReporteEstudiantesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(title: Text('Listado de estudiantes')),
      body: Center(child: Text('TODO: conectar endpoint + exportación.')),
    );
  }
}
