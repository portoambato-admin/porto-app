import 'package:flutter/material.dart';

class ProfesorAsistenciasScreen extends StatelessWidget {
  const ProfesorAsistenciasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(title: Text('Asistencias')),
      body: Center(child: Text('TODO: módulo de asistencias (solo asignados)')),
    );
  }
}
